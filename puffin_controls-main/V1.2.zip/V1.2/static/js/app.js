/**
 * Frontend JavaScript for Oscilloscope Control
 * Handles all API communication and UI updates
 */

class OscilloscopeController {
    constructor() {
        this.connected = false;
        this.currentTaskId = null;
        this.pollingInterval = null;
        this.syncInterval = null;
        this.syncEnabled = false;
        this.lastKnownState = {};
        this.userChangePending = false; // Flag to prevent sync conflicts during user changes
        this.initializeEventListeners();
    }
    
    initializeEventListeners() {
        // Connection controls
        document.getElementById('connectBtn').addEventListener('click', () => this.connect());
        document.getElementById('disconnectBtn').addEventListener('click', () => this.disconnect());
        
        // Configuration controls
        document.getElementById('applySettingsBtn').addEventListener('click', () => this.applySettings());
        
        // Acquisition controls
        document.getElementById('acquireBtn').addEventListener('click', () => this.acquireWaveform());
        document.getElementById('resetTriggerBtn').addEventListener('click', () => this.resetTrigger());
        document.getElementById('downloadBtn').addEventListener('click', () => this.downloadCSV());
        
        // Real-time sync toggle
        const syncToggle = document.getElementById('syncToggle');
        if (syncToggle) {
            syncToggle.addEventListener('change', (e) => this.toggleSync(e.target.checked));
        }
        
        // Add change listeners to all form controls for real-time updates
        this.addRealTimeChangeListeners();
    }
    
    async connect() {
        const ip = document.getElementById('ipAddress').value;
        const port = parseInt(document.getElementById('port').value);
        
        this.setConnectionState('connecting', 'Connecting...');
        
        try {
            const response = await fetch('/api/connect', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ ip, port })
            });
            
            const data = await response.json();
            
            if (data.status === 'connected') {
                this.connected = true;
                this.setConnectionState('connected', `Connected to ${data.idn}`);
                this.updateUIForConnection(true);
                this.showToast('Successfully connected to oscilloscope', 'success');
                
                // Start real-time sync if enabled
                if (this.syncEnabled) {
                    this.startRealTimeSync();
                }
            } else {
                this.setConnectionState('error', `Error: ${data.error}`);
                this.showToast(`Connection failed: ${data.error}`, 'error');
            }
        } catch (error) {
            this.setConnectionState('error', `Error: ${error.message}`);
            this.showToast(`Connection error: ${error.message}`, 'error');
        }
    }
    
    async disconnect() {
        this.setConnectionState('disconnecting', 'Disconnecting...');
        
        try {
            const response = await fetch('/api/disconnect', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                }
            });
            
            const data = await response.json();
            
            this.connected = false;
            this.setConnectionState('disconnected', 'Disconnected');
            this.updateUIForConnection(false);
            this.showToast('Disconnected from oscilloscope', 'info');
            
            // Stop real-time sync
            this.stopRealTimeSync();
            
        } catch (error) {
            this.setConnectionState('error', `Error: ${error.message}`);
            this.showToast(`Disconnect error: ${error.message}`, 'error');
        }
    }
    
    async applySettings() {
        if (!this.connected) {
            this.showToast('Not connected to oscilloscope', 'error');
            return;
        }
        
        // Gather configuration data
        const timeScale = parseFloat(document.getElementById('timeScale').value);
        const triggerMode = document.getElementById('triggerMode').value;
        const triggerSource = document.getElementById('triggerSource').value;
        const triggerSlope = document.querySelector('input[name="triggerSlope"]:checked').value;
        const triggerLevel = parseFloat(document.getElementById('triggerLevel').value);
        
        try {
            // Apply settings for all channels
            for (let ch = 1; ch <= 4; ch++) {
                const state = document.getElementById(`ch${ch}_state`).checked;
                const voltageScale = parseFloat(document.getElementById(`ch${ch}_vdiv`).value);
                const offset = parseFloat(document.getElementById(`ch${ch}_offset`).value);
                
                await fetch('/api/config/channel', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ 
                        channel: ch, 
                        state, 
                        voltage_scale: voltageScale,
                        offset: offset
                    })
                });
            }
            
            // Apply timebase settings
            await fetch('/api/config/timebase', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ time_scale: timeScale })
            });
            
            // Apply trigger settings
            await fetch('/api/config/trigger', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ 
                    mode: triggerMode, 
                    source: triggerSource, 
                    slope: triggerSlope, 
                    level: triggerLevel 
                })
            });
            
            this.showToast('Settings applied successfully', 'success');
            
        } catch (error) {
            this.showToast(`Failed to apply settings: ${error.message}`, 'error');
        }
    }
    
    async acquireWaveform() {
        if (!this.connected) {
            this.showToast('Not connected to oscilloscope', 'error');
            return;
        }
        
        // Get the selected acquisition channel
        const channel = parseInt(document.getElementById('acquisitionChannel').value);
        
        try {
            // Start acquisition
            const response = await fetch('/api/acquire', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ channel })
            });
            
            const data = await response.json();
            
            if (data.task_id) {
                this.currentTaskId = data.task_id;
                this.startPolling();
                this.updateAcquisitionUI(true, 'Starting acquisition...');
            } else {
                this.showToast(`Acquisition failed: ${data.error}`, 'error');
            }
            
        } catch (error) {
            this.showToast(`Acquisition error: ${error.message}`, 'error');
        }
    }
    
    startPolling() {
        if (this.pollingInterval) {
            clearInterval(this.pollingInterval);
        }
        
        this.pollingInterval = setInterval(async () => {
            try {
                const response = await fetch(`/api/acquire/status/${this.currentTaskId}`);
                const data = await response.json();
                
                this.updateAcquisitionStatus(data);
                
                if (data.status === 'complete' || data.status === 'error') {
                    clearInterval(this.pollingInterval);
                    this.pollingInterval = null;
                    this.currentTaskId = null;
                }
                
            } catch (error) {
                console.error('Polling error:', error);
                clearInterval(this.pollingInterval);
                this.pollingInterval = null;
                this.currentTaskId = null;
            }
        }, 500); // Poll every 500ms
    }
    
    updateAcquisitionStatus(data) {
        const statusElement = document.getElementById('acquisitionStatus');
        const statusText = document.getElementById('statusText');
        
        statusElement.style.display = 'block';
        statusText.textContent = data.progress;
        
        if (data.status === 'complete') {
            statusElement.className = 'alert alert-success';
            this.updateAcquisitionUI(false, 'Acquisition complete');
            
            if (data.result) {
                this.displayResults(data.result);
            }
            
        } else if (data.status === 'error') {
            statusElement.className = 'alert alert-danger';
            this.updateAcquisitionUI(false, 'Acquisition failed');
            this.showToast(`Acquisition error: ${data.error}`, 'error');
            
        } else {
            statusElement.className = 'alert alert-info';
        }
    }
    
    displayResults(result) {
        const plotContainer = document.getElementById('plotContainer');
        const fileInfo = document.getElementById('fileInfo');
        const csvFileName = document.getElementById('csvFileName');
        const plotFileName = document.getElementById('plotFileName');
        
        // Display plot if available
        if (result.plot_file) {
            plotContainer.innerHTML = `<img src="/api/plot/${result.plot_file}" class="img-fluid" alt="Waveform Plot">`;
        } else {
            plotContainer.innerHTML = '<div class="text-muted">Plot generation failed</div>';
        }
        
        // Display file information
        csvFileName.textContent = result.csv_file || 'N/A';
        plotFileName.textContent = result.plot_file || 'N/A';
        fileInfo.style.display = 'block';
        
        // Enable download button
        document.getElementById('downloadBtn').disabled = false;
    }
    
    async resetTrigger() {
        if (!this.connected) {
            this.showToast('Not connected to oscilloscope', 'error');
            return;
        }
        
        try {
            const response = await fetch('/api/reset-trigger', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' }
            });
            
            const data = await response.json();
            
            if (data.status === 'success') {
                this.showToast('Trigger reset and re-armed successfully', 'success');
            } else {
                this.showToast(`Reset failed: ${data.error}`, 'error');
            }
            
        } catch (error) {
            this.showToast(`Reset error: ${error.message}`, 'error');
        }
    }
    
    downloadCSV() {
        const csvFileName = document.getElementById('csvFileName').textContent;
        if (csvFileName && csvFileName !== 'N/A') {
            window.open(`/api/download/${csvFileName}`, '_blank');
        }
    }
    
    // Real-time Synchronization Methods
    addRealTimeChangeListeners() {
        // Channel settings listeners
        for (let ch = 1; ch <= 4; ch++) {
            const vdivInput = document.getElementById(`ch${ch}_vdiv`);
            const offsetInput = document.getElementById(`ch${ch}_offset`);
            const stateInput = document.getElementById(`ch${ch}_state`);
            
            if (vdivInput) {
                vdivInput.addEventListener('change', () => this.onChannelChange(ch, 'vdiv', parseFloat(vdivInput.value)));
            }
            if (offsetInput) {
                offsetInput.addEventListener('change', () => this.onChannelChange(ch, 'offset', parseFloat(offsetInput.value)));
            }
            if (stateInput) {
                stateInput.addEventListener('change', () => this.onChannelChange(ch, 'display', stateInput.checked));
            }
        }
        
        // Trigger settings listeners
        const triggerMode = document.getElementById('triggerMode');
        const triggerSource = document.getElementById('triggerSource');
        const triggerLevel = document.getElementById('triggerLevel');
        
        if (triggerMode) {
            triggerMode.addEventListener('change', () => this.onTriggerChange('mode', triggerMode.value));
        }
        if (triggerSource) {
            triggerSource.addEventListener('change', () => this.onTriggerChange('source', triggerSource.value));
        }
        if (triggerLevel) {
            triggerLevel.addEventListener('change', () => this.onTriggerChange('level', parseFloat(triggerLevel.value)));
        }
        
        // Trigger slope radio buttons
        const slopeInputs = document.querySelectorAll('input[name="triggerSlope"]');
        slopeInputs.forEach(input => {
            input.addEventListener('change', () => {
                if (input.checked) {
                    this.onTriggerChange('slope', input.value);
                }
            });
        });
        
        // Timebase settings
        const timeScale = document.getElementById('timeScale');
        if (timeScale) {
            timeScale.addEventListener('change', () => this.onTimebaseChange('horizontal_div', parseFloat(timeScale.value)));
        }
    }
    
    toggleSync(enabled) {
        this.syncEnabled = enabled;
        
        if (enabled && this.connected) {
            this.startRealTimeSync();
            this.showToast('Real-time synchronization enabled', 'success');
        } else {
            this.stopRealTimeSync();
            this.showToast('Real-time synchronization disabled', 'info');
        }
        
        // Update sync status on server
        fetch('/api/sync/enable', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ enabled })
        }).catch(err => console.error('Failed to update sync status:', err));
    }
    
    startRealTimeSync() {
        if (this.syncInterval) {
            clearInterval(this.syncInterval);
        }
        
        this.syncInterval = setInterval(() => this.pollScopeForChanges(), 1000); // Poll every second
        console.log('Real-time sync started');
    }
    
    stopRealTimeSync() {
        if (this.syncInterval) {
            clearInterval(this.syncInterval);
            this.syncInterval = null;
        }
        console.log('Real-time sync stopped');
    }
    
    async pollScopeForChanges() {
        if (!this.connected || !this.syncEnabled || this.userChangePending) {
            return;
        }
        
        try {
            const response = await fetch('/api/sync/poll');
            const data = await response.json();
            
            if (data.changes && Object.keys(data.changes).length > 0) {
                console.log('Scope changes detected:', data.changes);
                this.applyScopeChangesToUI(data.changes);
            }
            
        } catch (error) {
            console.error('Sync polling error:', error);
        }
    }
    
    applyScopeChangesToUI(changes) {
        // Temporarily disable user change handling to prevent feedback loop
        this.userChangePending = true;
        
        try {
            // Apply channel changes
            Object.keys(changes).forEach(changeKey => {
                if (changeKey.startsWith('channel_')) {
                    const channelNum = parseInt(changeKey.split('_')[1]);
                    const channelData = changes[changeKey];
                    
                    if (channelData.vdiv !== undefined) {
                        const vdivInput = document.getElementById(`ch${channelNum}_vdiv`);
                        if (vdivInput && parseFloat(vdivInput.value) !== channelData.vdiv) {
                            vdivInput.value = channelData.vdiv;
                            this.highlightChange(vdivInput);
                        }
                    }
                    
                    if (channelData.offset !== undefined) {
                        const offsetInput = document.getElementById(`ch${channelNum}_offset`);
                        if (offsetInput && parseFloat(offsetInput.value) !== channelData.offset) {
                            offsetInput.value = channelData.offset;
                            this.highlightChange(offsetInput);
                        }
                    }
                    
                    if (channelData.display !== undefined) {
                        const stateInput = document.getElementById(`ch${channelNum}_state`);
                        if (stateInput && stateInput.checked !== channelData.display) {
                            stateInput.checked = channelData.display;
                            this.highlightChange(stateInput.closest('td'));
                        }
                    }
                }
                
                else if (changeKey === 'trigger') {
                    const triggerData = changes.trigger;
                    
                    if (triggerData.mode) {
                        const modeInput = document.getElementById('triggerMode');
                        if (modeInput && modeInput.value !== triggerData.mode) {
                            modeInput.value = triggerData.mode;
                            this.highlightChange(modeInput);
                        }
                    }
                    
                    if (triggerData.source) {
                        const sourceInput = document.getElementById('triggerSource');
                        if (sourceInput && sourceInput.value !== triggerData.source) {
                            sourceInput.value = triggerData.source;
                            this.highlightChange(sourceInput);
                        }
                    }
                    
                    if (triggerData.slope) {
                        const slopeValue = triggerData.slope === 'RISE' ? 'RISing' : 'FALLing';
                        const currentSlope = document.querySelector('input[name="triggerSlope"]:checked')?.value;
                        if (currentSlope !== slopeValue) {
                            const slopeInput = triggerData.slope === 'RISE' ? 
                                document.getElementById('slopeRising') : 
                                document.getElementById('slopeFalling');
                            if (slopeInput) {
                                slopeInput.checked = true;
                                this.highlightChange(slopeInput.closest('.form-check'));
                            }
                        }
                    }
                }
                
                else if (changeKey === 'timebase') {
                    const timebaseData = changes.timebase;
                    if (timebaseData.horizontal_div) {
                        const timeScaleInput = document.getElementById('timeScale');
                        if (timeScaleInput && parseFloat(timeScaleInput.value) !== parseFloat(timebaseData.horizontal_div)) {
                            timeScaleInput.value = timebaseData.horizontal_div;
                            this.highlightChange(timeScaleInput);
                        }
                    }
                }
            });
            
        } finally {
            // Re-enable user change handling after a short delay
            setTimeout(() => {
                this.userChangePending = false;
            }, 100);
        }
    }
    
    highlightChange(element) {
        // Add visual indication that this field was updated from the scope
        element.style.backgroundColor = '#e8f5e8';
        element.style.transition = 'background-color 0.3s ease';
        
        setTimeout(() => {
            element.style.backgroundColor = '';
        }, 2000);
    }
    
    async onChannelChange(channel, property, value) {
        if (!this.connected || !this.syncEnabled || this.userChangePending) {
            return;
        }
        
        this.userChangePending = true;
        
        try {
            const changes = {};
            changes[`channel_${channel}`] = { [property]: value };
            
            await this.updateScopeFromUIChanges(changes);
            
        } finally {
            setTimeout(() => {
                this.userChangePending = false;
            }, 200);
        }
    }
    
    async onTriggerChange(property, value) {
        if (!this.connected || !this.syncEnabled || this.userChangePending) {
            return;
        }
        
        this.userChangePending = true;
        
        try {
            const changes = {
                trigger: { [property]: value }
            };
            
            await this.updateScopeFromUIChanges(changes);
            
        } finally {
            setTimeout(() => {
                this.userChangePending = false;
            }, 200);
        }
    }
    
    async onTimebaseChange(property, value) {
        if (!this.connected || !this.syncEnabled || this.userChangePending) {
            return;
        }
        
        this.userChangePending = true;
        
        try {
            const changes = {
                timebase: { [property]: value }
            };
            
            await this.updateScopeFromUIChanges(changes);
            
        } finally {
            setTimeout(() => {
                this.userChangePending = false;
            }, 200);
        }
    }
    
    async updateScopeFromUIChanges(changes) {
        try {
            const response = await fetch('/api/sync/update-scope', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ changes })
            });
            
            const data = await response.json();
            
            if (data.status !== 'success') {
                console.error('Failed to update scope:', data.error);
                this.showToast(`Sync failed: ${data.error}`, 'error');
            }
            
        } catch (error) {
            console.error('Scope update error:', error);
            this.showToast(`Sync error: ${error.message}`, 'error');
        }
    }
    
    setConnectionState(state, message) {
        const statusElement = document.getElementById('connectionStatus');
        const deviceIdElement = document.getElementById('deviceId');
        
        statusElement.className = 'badge';
        
        switch (state) {
            case 'connecting':
                statusElement.className += ' bg-warning';
                statusElement.textContent = 'Connecting...';
                break;
            case 'connected':
                statusElement.className += ' bg-success';
                statusElement.textContent = 'Connected';
                deviceIdElement.textContent = message;
                break;
            case 'disconnecting':
                statusElement.className += ' bg-warning';
                statusElement.textContent = 'Disconnecting...';
                break;
            case 'disconnected':
                statusElement.className += ' bg-secondary';
                statusElement.textContent = 'Disconnected';
                deviceIdElement.textContent = '';
                break;
            case 'error':
                statusElement.className += ' bg-danger';
                statusElement.textContent = 'Error';
                deviceIdElement.textContent = message;
                break;
        }
    }
    
    updateUIForConnection(connected) {
        document.getElementById('connectBtn').disabled = connected;
        document.getElementById('disconnectBtn').disabled = !connected;
        document.getElementById('applySettingsBtn').disabled = !connected;
        document.getElementById('acquireBtn').disabled = !connected;
        document.getElementById('resetTriggerBtn').disabled = !connected;
        
        // Enable/disable sync toggle based on connection
        const syncToggle = document.getElementById('syncToggle');
        if (syncToggle) {
            syncToggle.disabled = !connected;
            if (!connected) {
                syncToggle.checked = false;
                this.syncEnabled = false;
                this.stopRealTimeSync();
            }
        }
    }
    
    updateAcquisitionUI(acquiring, message) {
        document.getElementById('acquireBtn').disabled = acquiring;
        
        if (acquiring) {
            document.getElementById('acquireBtn').textContent = 'Acquiring...';
        } else {
            document.getElementById('acquireBtn').textContent = 'Acquire Waveform';
        }
    }
    
    showToast(message, type = 'info') {
        const toastElement = document.getElementById('toast');
        const toastBody = document.getElementById('toastBody');
        
        toastBody.textContent = message;
        
        // Set toast color based on type
        toastElement.className = 'toast';
        if (type === 'success') {
            toastElement.classList.add('text-bg-success');
        } else if (type === 'error') {
            toastElement.classList.add('text-bg-danger');
        } else if (type === 'warning') {
            toastElement.classList.add('text-bg-warning');
        } else {
            toastElement.classList.add('text-bg-info');
        }
        
        const toast = new bootstrap.Toast(toastElement);
        toast.show();
    }
}

// Initialize the application when the page loads
document.addEventListener('DOMContentLoaded', () => {
    new OscilloscopeController();

    // Function to update UI fields from config data
    function updateUIFromConfig(config) {
        // Update connection fields
        if (config.ip) {
            document.getElementById('ipAddress').value = config.ip;
        }
        if (config.port) {
            document.getElementById('port').value = config.port;
        }
        
        // Update channel settings - populate all channels in the table
        const channels = config.settings?.channels || {};
        for (let ch = 1; ch <= 4; ch++) {
            const chKey = `CH${ch}`;
            if (channels[chKey]) {
                const chSettings = channels[chKey];
                
                // Set voltage scale
                if (chSettings.vdiv !== undefined) {
                    document.getElementById(`ch${ch}_vdiv`).value = chSettings.vdiv;
                }
                
                // Set offset (default to 0 if not specified)
                const offset = chSettings.offset || 0;
                document.getElementById(`ch${ch}_offset`).value = offset;
                
                // Set channel state
                const channelState = chSettings.display === 'on';
                document.getElementById(`ch${ch}_state`).checked = channelState;
            }
        }
        
        // Update trigger settings
        const trigger = config.settings?.trigger || {};
        if (trigger.source) {
            const sourceMap = {'EXT': 'EX', 'EX': 'EX'};
            document.getElementById('triggerSource').value = sourceMap[trigger.source] || trigger.source;
        }
        if (trigger.mode) {
            document.getElementById('triggerMode').value = trigger.mode;
        }
        if (trigger.slope) {
            const slopeRadio = trigger.slope === 'RISE' ? 'slopeRising' : 'slopeFalling';
            document.getElementById(slopeRadio).checked = true;
        }
        
        // Update timebase settings
        const timescale = config.settings?.timescale || {};
        if (timescale.horizontal_div) {
            document.getElementById('timeScale').value = parseFloat(timescale.horizontal_div);
        }
    }

    // Write Scope Settings to JSON Handler
    const writeScopeToJsonBtn = document.getElementById('writeScopeToJsonBtn');
    if (writeScopeToJsonBtn) {
        writeScopeToJsonBtn.addEventListener('click', async () => {
            const statusDiv = document.getElementById('importConfigStatus');
            statusDiv.textContent = 'Writing scope settings to JSON...';
            statusDiv.className = 'small text-info mt-2';
            
            try {
                const response = await fetch('/api/write-scope-to-json', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' }
                });
                
                const data = await response.json();
                if (data.status === 'success') {
                    statusDiv.textContent = data.message;
                    statusDiv.className = 'small text-success mt-2';
                } else {
                    statusDiv.textContent = 'Write error: ' + (data.error || 'Unknown error');
                    statusDiv.className = 'small text-danger mt-2';
                }
            } catch (err) {
                statusDiv.textContent = 'Write failed: ' + err.message;
                statusDiv.className = 'small text-danger mt-2';
            }
        });
    }

    // Set Scope Settings from JSON Handler
    const setScopeFromJsonBtn = document.getElementById('setScopeFromJsonBtn');
    if (setScopeFromJsonBtn) {
        setScopeFromJsonBtn.addEventListener('click', async () => {
            const statusDiv = document.getElementById('importConfigStatus');
            const fileInput = document.getElementById('importConfigFile');
            
            statusDiv.textContent = 'Loading settings...';
            statusDiv.className = 'small text-info mt-2';
            
            try {
                let response;
                
                // Check if a file is selected
                if (fileInput && fileInput.files.length > 0) {
                    // Use the selected file
                    const formData = new FormData();
                    formData.append('file', fileInput.files[0]);
                    
                    response = await fetch('/api/import-config', {
                        method: 'POST',
                        body: formData
                    });
                } else {
                    // Use the existing device settings.json file
                    response = await fetch('/api/set-scope-from-json', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' }
                    });
                }
                
                const data = await response.json();
                if (data.status === 'success') {
                    // Show appropriate message based on connection status
                    if (data.connection_error) {
                        statusDiv.textContent = `Settings loaded for UI (scope not connected: ${data.connection_error})`;
                        statusDiv.className = 'small text-warning mt-2';
                    } else {
                        statusDiv.textContent = data.message || 'Settings loaded and applied successfully';
                        statusDiv.className = 'small text-success mt-2';
                    }
                    
                    // Update GUI fields with config data (works regardless of connection)
                    updateUIFromConfig(data.config);
                    
                    // Clear file selection after successful import
                    if (fileInput && fileInput.files.length > 0) {
                        fileInput.value = '';
                    }
                    
                } else {
                    statusDiv.textContent = 'Error: ' + (data.error || 'Unknown error');
                    statusDiv.className = 'small text-danger mt-2';
                }
            } catch (err) {
                statusDiv.textContent = 'Failed: ' + err.message;
                statusDiv.className = 'small text-danger mt-2';
            }
        });
    }
});
