#!/usr/bin/env python3
"""
Basic test script for Flask oscilloscope control
Tests core functionality without requiring actual oscilloscope connection
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from scope_manager import ScopeManager
import app

def test_scope_manager():
    """Test ScopeManager basic functionality"""
    print("Testing ScopeManager...")
    
    manager = ScopeManager()
    
    # Test initial state
    assert not manager.get_active_scope()
    assert manager.active_ip is None
    print("✓ Initial state correct")
    
    # Test getting non-existent scope
    assert manager.get_scope("192.168.1.99") is None
    print("✓ Non-existent scope handling correct")
    
    print("✓ ScopeManager tests passed")

def test_flask_app():
    """Test Flask app basic functionality"""
    print("Testing Flask app...")
    
    # Test app creation
    assert app.app is not None
    print("✓ Flask app created")
    
    # Test routes exist
    routes = [rule.rule for rule in app.app.url_map.iter_rules()]
    expected_routes = ['/', '/api/connect', '/api/disconnect', '/api/config/channel', 
                      '/api/config/timebase', '/api/config/trigger', '/api/acquire']
    
    for route in expected_routes:
        assert route in routes, f"Route {route} not found"
    
    print("✓ All expected routes present")
    
    # Test waveform directory creation
    assert os.path.exists(app.WAVEFORM_DIR)
    print("✓ Waveform directory exists")
    
    print("✓ Flask app tests passed")

def test_plot_function():
    """Test plotting function with dummy data"""
    print("Testing plot function...")
    
    import pandas as pd
    import numpy as np
    from datetime import datetime
    
    # Create dummy CSV data
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    test_csv = os.path.join(app.WAVEFORM_DIR, f"test_waveform_{timestamp}.csv")
    test_plot = os.path.join(app.WAVEFORM_DIR, f"test_plot_{timestamp}.png")
    
    # Generate test data
    time_data = np.linspace(0, 1e-3, 1000)  # 1ms, 1000 points
    voltage_data = np.sin(2 * np.pi * 1000 * time_data)  # 1kHz sine wave
    
    # Save test CSV
    df = pd.DataFrame({'Time (s)': time_data, 'Voltage (V)': voltage_data})
    df.to_csv(test_csv, index=False)
    print("✓ Test CSV created")
    
    # Test plot creation
    success = app.create_plot(test_csv, test_plot)
    assert success, "Plot creation failed"
    assert os.path.exists(test_plot), "Plot file not created"
    print("✓ Plot created successfully")
    
    # Cleanup
    os.remove(test_csv)
    os.remove(test_plot)
    print("✓ Test files cleaned up")
    
    print("✓ Plot function tests passed")

if __name__ == "__main__":
    print("Running basic tests for Flask oscilloscope control...")
    print("=" * 60)
    
    try:
        test_scope_manager()
        print()
        test_flask_app()
        print()
        test_plot_function()
        print()
        print("=" * 60)
        print("✅ All basic tests passed!")
        print("The Flask app is ready for testing with a real oscilloscope.")
        print()
        print("To start the app, run:")
        print("  cd /Users/immanuelkoshy/Documents/puffin_controls-main/V1.1")
        print("  python3 app.py")
        print()
        print("Then open http://localhost:5000 in your browser")
        
    except Exception as e:
        print(f"❌ Test failed: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
