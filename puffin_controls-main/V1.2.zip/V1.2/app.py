#!/usr/bin/env python3
"""
Flask web application for oscilloscope control
Provides web UI for controlling Siglent SDS5104X oscilloscope
"""

from flask import Flask, render_template, request, jsonify, send_file, abort
import json
from concurrent.futures import ThreadPoolExecutor, Future
import uuid
import os
import time
import traceback
from datetime import datetime
import matplotlib
matplotlib.use('Agg')  # Use non-interactive backend
import matplotlib.pyplot as plt
import pandas as pd

from scope_manager import ScopeManager

app = Flask(__name__)

# Global scope manager and task executor
scope_manager = ScopeManager()
executor = ThreadPoolExecutor(max_workers=4)
tasks = {}  # {task_id: {"future": Future, "status": dict}}

# Real-time synchronization state
last_scope_state = {}  # Cache of last known scope settings
sync_enabled = True  # Global flag to enable/disable sync


# --- JSON Import Endpoint ---
@app.route('/api/import-config', methods=['POST'])
def api_import_config():
    """Import oscilloscope configuration from a JSON script"""
    try:
        if request.content_type.startswith('application/json'):
            config = request.get_json()
        elif request.content_type.startswith('multipart/form-data'):
            if 'file' not in request.files:
                return jsonify({"error": "No file part in request"}), 400
            file = request.files['file']
            config = json.load(file)
        else:
            return jsonify({"error": "Unsupported content type"}), 400

        # Validate required fields
        instrument = config.get('instrument')
        ip = config.get('ip')
        port = config.get('port', 5025)
        settings = config.get('settings', {})
        if not instrument or not ip:
            return jsonify({"error": "Missing required fields: instrument, ip"}), 400

        # Try to connect to scope (optional - config can be imported without connection)
        scope = None
        idn = None
        connection_error = None
        
        try:
            future = executor.submit(scope_manager.connect_scope, ip, port, 15.0)
            success, idn, error = future.result(timeout=20)
            if success:
                scope = scope_manager.get_scope(ip)
            else:
                connection_error = error
        except Exception as e:
            connection_error = str(e)

        # Apply settings to scope if connected
        applied_settings = {}
        if scope:
            # Apply channel settings
            channels = settings.get('channels', {})
            for ch_name, ch_settings in channels.items():
                if ch_name.startswith('CH'):
                    ch_num = int(ch_name[2:])  # Extract channel number from CH1, CH2, etc.
                    vdiv = ch_settings.get('vdiv')
                    display = ch_settings.get('display', 'on')
                    
                    if vdiv is not None:
                        try:
                            scope.set_voltage_scale(ch_num, vdiv)
                            scope.set_channel_state(ch_num, display.lower() == 'on')
                            applied_settings[f'channel_{ch_num}'] = {'vdiv': vdiv, 'display': display}
                        except Exception as e:
                            return jsonify({"error": f"Failed to set channel {ch_num}: {e}"}), 400
            
            # Apply trigger settings
            trigger = settings.get('trigger', {})
            if trigger:
                try:
                    trigger_source = trigger.get('source', 'EX')
                    trigger_slope = trigger.get('slope', 'RISing')
                    trigger_mode = trigger.get('mode', 'SINGLE')
                    
                    scope.send_command(f":TRIGger:EDGE:SOURce {trigger_source}")
                    scope.send_command(f":TRIGger:EDGE:SLOPe {trigger_slope}")
                    scope.set_trigger_mode(trigger_mode)
                    applied_settings['trigger'] = trigger
                except Exception as e:
                    return jsonify({"error": f"Failed to set trigger: {e}"}), 400
            
            # Apply timebase settings
            timescale = settings.get('timescale', {})
            horizontal_div = timescale.get('horizontal_div')
            if horizontal_div:
                try:
                    time_scale = float(horizontal_div)
                    scope.set_time_scale(time_scale)
                    applied_settings['timescale'] = timescale
                except Exception as e:
                    return jsonify({"error": f"Failed to set timebase: {e}"}), 400

        # Return success with config data for UI update (regardless of connection status)
        result = {
            "status": "success", 
            "config": config,  # Return the full config for UI update
            "applied_settings": applied_settings
        }
        
        if scope:
            result["idn"] = idn
            result["message"] = "Config imported and applied to oscilloscope successfully"
        else:
            result["message"] = f"Config imported for UI update only (connection failed: {connection_error})"
            result["connection_error"] = connection_error
        
        return jsonify(result)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/api/upload-json', methods=['POST'])
def api_upload_json():
    """Upload a JSON file and save it as device settings.json"""
    try:
        if 'file' not in request.files:
            return jsonify({"error": "No file part in request"}), 400
        
        file = request.files['file']
        if file.filename == '':
            return jsonify({"error": "No file selected"}), 400
        
        # Parse and validate JSON
        try:
            config = json.load(file)
        except json.JSONDecodeError as e:
            return jsonify({"error": f"Invalid JSON format: {e}"}), 400
        
        # Basic validation
        if not config.get('instrument') or not config.get('ip'):
            return jsonify({"error": "Missing required fields: instrument, ip"}), 400
        
        # Save to device settings.json
        json_file_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "device settings.json")
        with open(json_file_path, 'w') as f:
            json.dump(config, f, indent=2)
        
        return jsonify({
            "status": "success",
            "message": "File uploaded and saved as device settings.json"
        })
        
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/api/write-scope-to-json', methods=['POST'])
def api_write_scope_to_json():
    """Write current scope settings to JSON file"""
    try:
        scope = scope_manager.get_active_scope()
        if not scope:
            return jsonify({"error": "Not connected to oscilloscope"}), 400

        # Get current scope settings
        def read_scope_settings():
            settings = {
                "instrument": "Siglent SDS5104X",
                "serial number": scope.query("*IDN?").split(',')[2] if scope.query("*IDN?") else "Unknown",
                "ip": scope.ip_address,
                "port": scope.port,
                "settings": {
                    "channels": {},
                    "trigger": {},
                    "timescale": {}
                }
            }
            
            # Read channel settings
            for ch in range(1, 5):
                try:
                    vdiv = scope.query(f":C{ch}:VDIv?")
                    offset = scope.query(f":C{ch}:OFFSet?")
                    state = scope.query(f":C{ch}:TRace?")
                    
                    settings["settings"]["channels"][f"CH{ch}"] = {
                        "vdiv": float(vdiv) if vdiv else 1.0,
                        "offset": float(offset) if offset else 0.0,
                        "display": "on" if state and state.strip().upper() == "ON" else "off"
                    }
                except Exception as e:
                    print(f"Warning: Could not read channel {ch} settings: {e}")
                    settings["settings"]["channels"][f"CH{ch}"] = {
                        "vdiv": 1.0,
                        "offset": 0.0,
                        "display": "on"
                    }
            
            # Read trigger settings
            try:
                trigger_source = scope.query(":TRIGger:EDGE:SOURce?")
                trigger_slope = scope.query(":TRIGger:EDGE:SLOPe?")
                trigger_mode = scope.query(":TRIGger:MODE?")
                
                settings["settings"]["trigger"] = {
                    "source": trigger_source.strip() if trigger_source else "EXT",
                    "slope": trigger_slope.strip() if trigger_slope else "RISE",
                    "mode": trigger_mode.strip() if trigger_mode else "SINGLE"
                }
            except Exception as e:
                print(f"Warning: Could not read trigger settings: {e}")
                settings["settings"]["trigger"] = {
                    "source": "EXT",
                    "slope": "RISE",
                    "mode": "SINGLE"
                }
            
            # Read timebase settings
            try:
                time_scale = scope.query(":TIMebase:SCALe?")
                settings["settings"]["timescale"] = {
                    "horizontal_div": time_scale.strip() if time_scale else "1E-3"
                }
            except Exception as e:
                print(f"Warning: Could not read timebase settings: {e}")
                settings["settings"]["timescale"] = {
                    "horizontal_div": "1E-3"
                }
            
            return settings

        # Run in thread pool
        future = executor.submit(read_scope_settings)
        settings = future.result(timeout=15)
        
        # Write to JSON file
        json_file_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "device settings.json")
        with open(json_file_path, 'w') as f:
            json.dump(settings, f, indent=2)
        
        return jsonify({
            "status": "success",
            "message": "Scope settings written to 'device settings.json'",
            "settings": settings
        })
        
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/api/set-scope-from-json', methods=['POST'])
def api_set_scope_from_json():
    """Set scope settings from the device settings.json file"""
    try:
        # Read the JSON file first (works regardless of connection)
        json_file_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "device settings.json")
        if not os.path.exists(json_file_path):
            return jsonify({"error": "device settings.json file not found"}), 400
        
        with open(json_file_path, 'r') as f:
            config = json.load(f)
        
        scope = scope_manager.get_active_scope()
        settings = config.get('settings', {})
        applied_settings = {}
        connection_error = None
        
        # Apply settings to scope if connected
        if scope:
            # Apply channel settings
            channels = settings.get('channels', {})
            for ch_name, ch_settings in channels.items():
                if ch_name.startswith('CH'):
                    ch_num = int(ch_name[2:])
                    vdiv = ch_settings.get('vdiv')
                    offset = ch_settings.get('offset', 0)
                    display = ch_settings.get('display', 'on')
                    
                    try:
                        if vdiv is not None:
                            scope.set_voltage_scale(ch_num, vdiv)
                        scope.send_command(f":C{ch_num}:OFFSet {offset}")
                        scope.set_channel_state(ch_num, display.lower() == 'on')
                        applied_settings[f'channel_{ch_num}'] = {'vdiv': vdiv, 'offset': offset, 'display': display}
                    except Exception as e:
                        return jsonify({"error": f"Failed to set channel {ch_num}: {e}"}), 400
            
            # Apply trigger settings
            trigger = settings.get('trigger', {})
            if trigger:
                try:
                    trigger_source = trigger.get('source', 'EX')
                    trigger_slope = trigger.get('slope', 'RISing')
                    trigger_mode = trigger.get('mode', 'SINGLE')
                    
                    scope.send_command(f":TRIGger:EDGE:SOURce {trigger_source}")
                    scope.send_command(f":TRIGger:EDGE:SLOPe {trigger_slope}")
                    scope.set_trigger_mode(trigger_mode)
                    applied_settings['trigger'] = trigger
                except Exception as e:
                    return jsonify({"error": f"Failed to set trigger: {e}"}), 400
            
            # Apply timebase settings
            timescale = settings.get('timescale', {})
            horizontal_div = timescale.get('horizontal_div')
            if horizontal_div:
                try:
                    time_scale = float(horizontal_div)
                    scope.set_time_scale(time_scale)
                    applied_settings['timescale'] = timescale
                except Exception as e:
                    return jsonify({"error": f"Failed to set timebase: {e}"}), 400
        else:
            connection_error = "Not connected to oscilloscope"

        # Return success with config data for UI update (regardless of connection status)
        result = {
            "status": "success",
            "config": config,  # Return the full config for UI update
            "applied_settings": applied_settings
        }
        
        if scope:
            result["message"] = "Settings applied from 'device settings.json'"
        else:
            result["message"] = "Settings loaded for UI update only (scope not connected)"
            result["connection_error"] = connection_error
        
        return jsonify(result)
        
    except Exception as e:
        return jsonify({"error": str(e)}), 500
        
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# Ensure waveform_data directory exists
WAVEFORM_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "waveform_data")
os.makedirs(WAVEFORM_DIR, exist_ok=True)

def create_plot(csv_file, plot_file):
    """
    Create matplotlib plot from CSV file and save as PNG
    
    Args:
        csv_file (str): Path to CSV file
        plot_file (str): Path to save plot PNG
        
    Returns:
        bool: Success status
    """
    try:
        df = pd.read_csv(csv_file)
        if "Time (s)" not in df.columns or "Voltage (V)" not in df.columns:
            print(f"Error: CSV file '{csv_file}' does not contain expected columns.")
            return False
        
        time_data = df["Time (s)"]
        voltage_data = df["Voltage (V)"]
        
        plt.figure(figsize=(12, 6))
        plt.plot(time_data * 1e6, voltage_data)  # Plot time in microseconds
        plt.title(f"Waveform Data from {os.path.basename(csv_file)}")
        plt.xlabel("Time (μs)")
        plt.ylabel("Voltage (V)")
        plt.grid(True)
        plt.margins(x=0.01, y=0.1)
        plt.ticklabel_format(style='sci', axis='x', scilimits=(0,0))
        plt.tight_layout()
        plt.savefig(plot_file, dpi=100, bbox_inches='tight')
        plt.close()  # Important: close figure to free memory
        
        return True
        
    except Exception as e:
        print(f"Error creating plot: {e}")
        traceback.print_exc()
        return False

def acquire_waveform_worker(scope, channel, task_id):
    """
    Background worker for waveform acquisition
    
    Args:
        scope: SocketScope instance
        channel (int): Channel number
        task_id (str): Task identifier
    """
    try:
        # Update status
        tasks[task_id]["status"] = {
            "status": "pending",
            "progress": "Arming trigger...",
            "result": None,
            "error": None
        }
        
        # Set trigger mode to SINGLE
        scope.set_trigger_mode("SINGLE")
        
        # Update status
        tasks[task_id]["status"]["progress"] = "Waiting for trigger..."
        
        # Event-driven polling for trigger status
        poll_timeout = 30  # seconds
        poll_interval = 0.1  # 100ms polling
        start_time = time.time()
        triggered = False
        
        print(f"Polling for trigger event (timeout: {poll_timeout}s)...")
        
        while time.time() - start_time < poll_timeout:
            try:
                trig_status = scope.query(":TRIGger:STATus?")
                print(f"Trigger status: {trig_status}")
                
                if trig_status in ["Stop", "FStop", "Trig'd"]:
                    triggered = True
                    print(f"✓ Trigger detected! Scope status: {trig_status}")
                    break
                elif trig_status in ["Ready", "Arm", "Auto"]:
                    # Scope is armed and waiting - continue polling
                    time.sleep(poll_interval)
                else:
                    # Unknown status - log and continue
                    print(f"Unknown trigger status: {trig_status}")
                    time.sleep(poll_interval)
                    
            except Exception as e:
                print(f"Error polling trigger status: {e}")
                time.sleep(poll_interval)
        
        if not triggered:
            print(f"✗ Trigger event not detected within {poll_timeout} seconds.")
            tasks[task_id]["status"] = {
                "status": "error",
                "progress": f"Timeout waiting for trigger after {poll_timeout}s",
                "result": None,
                "error": f"Trigger timeout after {poll_timeout} seconds. Check external trigger signal."
            }
            return
        
        # Update status
        tasks[task_id]["status"]["progress"] = "Acquiring waveform data..."
        
        # Generate filenames
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        csv_file = os.path.join(WAVEFORM_DIR, f"waveform_ch{channel}_{timestamp}.csv")
        plot_file = os.path.join(WAVEFORM_DIR, f"plot_ch{channel}_{timestamp}.png")
        
        # Acquire and save waveform data
        saved_csv = scope.save_waveform_csv(channel, filename=csv_file)
        
        if not saved_csv:
            tasks[task_id]["status"] = {
                "status": "error",
                "progress": "Failed to acquire waveform data",
                "result": None,
                "error": "Waveform acquisition failed"
            }
            return
        
        # Create plot
        plot_success = create_plot(csv_file, plot_file)
        
        # Update status to complete
        tasks[task_id]["status"] = {
            "status": "complete",
            "progress": "Acquisition complete",
            "result": {
                "csv_file": os.path.basename(csv_file),
                "plot_file": os.path.basename(plot_file) if plot_success else None
            },
            "error": None
        }
        
    except Exception as e:
        print(f"Error in acquire_waveform_worker: {e}")
        traceback.print_exc()
        tasks[task_id]["status"] = {
            "status": "error",
            "progress": "Error during acquisition",
            "result": None,
            "error": str(e)
        }

@app.route('/')
def index():
    """Main page"""
    return render_template('index.html')

# Connection Management API
@app.route('/api/connect', methods=['POST'])
def api_connect():
    """Connect to oscilloscope"""
    try:
        data = request.get_json()
        ip = data.get('ip', '192.168.1.10')
        port = data.get('port', 5025)
        timeout = data.get('timeout', 15.0)
        
        # Run connection in thread pool
        future = executor.submit(scope_manager.connect_scope, ip, port, timeout)
        success, idn, error = future.result(timeout=20)  # 20s timeout for connection
        
        if success:
            return jsonify({
                "status": "connected",
                "idn": idn,
                "error": None
            })
        else:
            return jsonify({
                "status": "error",
                "idn": None,
                "error": error
            }), 400
            
    except Exception as e:
        return jsonify({
            "status": "error",
            "idn": None,
            "error": str(e)
        }), 500

@app.route('/api/disconnect', methods=['POST'])
def api_disconnect():
    """Disconnect from oscilloscope"""
    try:
        scope = scope_manager.get_active_scope()
        if not scope:
            return jsonify({
                "status": "disconnected",
                "error": None
            })
        
        # Run disconnection in thread pool
        future = executor.submit(scope_manager.disconnect_scope, scope.ip_address)
        success, error = future.result(timeout=10)
        
        return jsonify({
            "status": "disconnected",
            "error": error
        })
        
    except Exception as e:
        return jsonify({
            "status": "error",
            "error": str(e)
        }), 500

# Configuration API
@app.route('/api/config/channel', methods=['POST'])
def api_config_channel():
    """Configure channel settings"""
    try:
        scope = scope_manager.get_active_scope()
        if not scope:
            return jsonify({"error": "Not connected to oscilloscope"}), 400
        
        data = request.get_json()
        channel = data.get('channel', 1)
        state = data.get('state', True)
        voltage_scale = data.get('voltage_scale', 1.0)
        offset = data.get('offset', 0.0)
        
        # Run configuration in thread pool
        def config_worker():
            scope.set_channel_state(channel, state)
            scope.set_voltage_scale(channel, voltage_scale)
            # Add offset setting if the scope supports it
            try:
                scope.send_command(f":C{channel}:OFFSet {offset}")
            except Exception as e:
                print(f"Warning: Could not set offset for channel {channel}: {e}")
        
        future = executor.submit(config_worker)
        future.result(timeout=10)
        
        return jsonify({"status": "success"})
        
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# Real-time Synchronization API
@app.route('/api/sync/status', methods=['GET'])
def api_sync_status():
    """Get current synchronization settings and last known state"""
    global sync_enabled, last_scope_state
    
    return jsonify({
        "sync_enabled": sync_enabled,
        "connected": scope_manager.get_active_scope() is not None,
        "last_state": last_scope_state
    })

@app.route('/api/sync/enable', methods=['POST'])
def api_sync_enable():
    """Enable or disable real-time synchronization"""
    global sync_enabled
    
    data = request.get_json()
    sync_enabled = data.get('enabled', True)
    
    return jsonify({
        "status": "success",
        "sync_enabled": sync_enabled
    })

@app.route('/api/sync/poll', methods=['GET'])
def api_sync_poll():
    """Poll oscilloscope for current settings and return any changes"""
    global last_scope_state
    
    try:
        scope = scope_manager.get_active_scope()
        if not scope:
            return jsonify({"error": "Not connected to oscilloscope"}), 400
        
        if not sync_enabled:
            return jsonify({"sync_enabled": False, "changes": {}})
        
        def poll_scope_settings():
            current_state = {}
            changes = {}
            
            try:
                # Read channel settings
                for ch in range(1, 5):
                    try:
                        vdiv = scope.query(f":C{ch}:VDIv?")
                        offset = scope.query(f":C{ch}:OFFSet?")
                        state = scope.query(f":C{ch}:TRace?")
                        
                        channel_state = {
                            "vdiv": float(vdiv) if vdiv else 1.0,
                            "offset": float(offset) if offset else 0.0,
                            "display": state and state.strip().upper() == "ON"
                        }
                        
                        current_state[f"channel_{ch}"] = channel_state
                        
                        # Check for changes
                        last_channel = last_scope_state.get(f"channel_{ch}", {})
                        if channel_state != last_channel:
                            changes[f"channel_{ch}"] = channel_state
                            
                    except Exception as e:
                        print(f"Warning: Could not read channel {ch} settings: {e}")
                
                # Read trigger settings
                try:
                    trigger_source = scope.query(":TRIGger:EDGE:SOURce?")
                    trigger_slope = scope.query(":TRIGger:EDGE:SLOPe?")
                    trigger_mode = scope.query(":TRIGger:MODE?")
                    
                    trigger_state = {
                        "source": trigger_source.strip() if trigger_source else "EXT",
                        "slope": trigger_slope.strip() if trigger_slope else "RISE",
                        "mode": trigger_mode.strip() if trigger_mode else "SINGLE"
                    }
                    
                    current_state["trigger"] = trigger_state
                    
                    # Check for changes
                    last_trigger = last_scope_state.get("trigger", {})
                    if trigger_state != last_trigger:
                        changes["trigger"] = trigger_state
                        
                except Exception as e:
                    print(f"Warning: Could not read trigger settings: {e}")
                
                # Read timebase settings
                try:
                    time_scale = scope.query(":TIMebase:SCALe?")
                    timebase_state = {
                        "horizontal_div": time_scale.strip() if time_scale else "1E-3"
                    }
                    
                    current_state["timebase"] = timebase_state
                    
                    # Check for changes
                    last_timebase = last_scope_state.get("timebase", {})
                    if timebase_state != last_timebase:
                        changes["timebase"] = timebase_state
                        
                except Exception as e:
                    print(f"Warning: Could not read timebase settings: {e}")
                
                # Update cached state
                last_scope_state = current_state
                
                return {
                    "sync_enabled": True,
                    "changes": changes,
                    "full_state": current_state,
                    "timestamp": time.time()
                }
                
            except Exception as e:
                return {"error": f"Failed to poll scope settings: {str(e)}"}
        
        # Run polling in thread pool
        future = executor.submit(poll_scope_settings)
        result = future.result(timeout=10)
        
        return jsonify(result)
        
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/api/sync/update-scope', methods=['POST'])
def api_sync_update_scope():
    """Update oscilloscope settings from GUI changes"""
    try:
        scope = scope_manager.get_active_scope()
        if not scope:
            return jsonify({"error": "Not connected to oscilloscope"}), 400
        
        data = request.get_json()
        changes = data.get('changes', {})
        
        def update_scope_worker():
            applied_changes = {}
            
            # Apply channel changes
            for change_key, change_data in changes.items():
                if change_key.startswith('channel_'):
                    ch_num = int(change_key.split('_')[1])
                    
                    try:
                        if 'vdiv' in change_data:
                            scope.set_voltage_scale(ch_num, float(change_data['vdiv']))
                        
                        if 'offset' in change_data:
                            scope.send_command(f":C{ch_num}:OFFSet {float(change_data['offset'])}")
                        
                        if 'display' in change_data:
                            scope.set_channel_state(ch_num, bool(change_data['display']))
                        
                        applied_changes[change_key] = change_data
                        
                    except Exception as e:
                        print(f"Failed to update channel {ch_num}: {e}")
                        return {"error": f"Failed to update channel {ch_num}: {str(e)}"}
                
                elif change_key == 'trigger':
                    try:
                        trigger_data = change_data
                        if 'source' in trigger_data:
                            scope.send_command(f":TRIGger:EDGE:SOURce {trigger_data['source']}")
                        if 'slope' in trigger_data:
                            scope.send_command(f":TRIGger:EDGE:SLOPe {trigger_data['slope']}")
                        if 'mode' in trigger_data:
                            scope.set_trigger_mode(trigger_data['mode'])
                        
                        applied_changes[change_key] = change_data
                        
                    except Exception as e:
                        print(f"Failed to update trigger: {e}")
                        return {"error": f"Failed to update trigger: {str(e)}"}
                
                elif change_key == 'timebase':
                    try:
                        timebase_data = change_data
                        if 'horizontal_div' in timebase_data:
                            scope.set_time_scale(float(timebase_data['horizontal_div']))
                        
                        applied_changes[change_key] = change_data
                        
                    except Exception as e:
                        print(f"Failed to update timebase: {e}")
                        return {"error": f"Failed to update timebase: {str(e)}"}
            
            return {"status": "success", "applied_changes": applied_changes}
        
        # Run update in thread pool
        future = executor.submit(update_scope_worker)
        result = future.result(timeout=10)
        
        return jsonify(result)
        
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/api/config/timebase', methods=['POST'])
def api_config_timebase():
    """Configure timebase settings"""
    try:
        scope = scope_manager.get_active_scope()
        if not scope:
            return jsonify({"error": "Not connected to oscilloscope"}), 400
        
        data = request.get_json()
        time_scale = data.get('time_scale', 1e-6)
        
        # Run configuration in thread pool
        future = executor.submit(scope.set_time_scale, time_scale)
        future.result(timeout=10)
        
        return jsonify({"status": "success"})
        
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/api/config/trigger', methods=['POST'])
def api_config_trigger():
    """Configure trigger settings"""
    try:
        scope = scope_manager.get_active_scope()
        if not scope:
            return jsonify({"error": "Not connected to oscilloscope"}), 400
        
        data = request.get_json()
        mode = data.get('mode', 'SINGLE')
        source = data.get('source', 'EX')
        slope = data.get('slope', 'RISing')
        level = data.get('level', 0.5)
        
        # Run configuration in thread pool
        def trigger_worker():
            scope.send_command(":TRIGger:TYPE EDGE")
            scope.send_command(f":TRIGger:EDGE:SOURce {source}")
            scope.send_command(f":TRIGger:EDGE:SLOPe {slope}")
            scope.send_command(f":TRIGger:EDGE:LEVel {level}")
            scope.set_trigger_mode(mode)
        
        future = executor.submit(trigger_worker)
        future.result(timeout=10)
        
        return jsonify({"status": "success"})
        
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# Acquisition API
@app.route('/api/acquire', methods=['POST'])
def api_acquire():
    """Start waveform acquisition"""
    try:
        scope = scope_manager.get_active_scope()
        if not scope:
            return jsonify({"error": "Not connected to oscilloscope"}), 400
        
        data = request.get_json()
        channel = data.get('channel', 1)
        
        # Create acquisition task
        task_id = str(uuid.uuid4())
        future = executor.submit(acquire_waveform_worker, scope, channel, task_id)
        tasks[task_id] = {
            "future": future,
            "status": {
                "status": "pending",
                "progress": "Starting acquisition...",
                "result": None,
                "error": None
            }
        }
        
        return jsonify({"task_id": task_id})
        
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/api/acquire/status/<task_id>', methods=['GET'])
def api_acquire_status(task_id):
    """Get acquisition status"""
    try:
        if task_id not in tasks:
            return jsonify({"error": "Task not found"}), 404
        
        return jsonify(tasks[task_id]["status"])
        
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/api/reset-trigger', methods=['POST'])
def api_reset_trigger():
    """Reset trigger state and re-arm for single acquisition"""
    try:
        scope = scope_manager.get_active_scope()
        if not scope:
            return jsonify({"error": "Not connected to oscilloscope"}), 400
        
        # Run reset in thread pool
        def reset_worker():
            # Reset to AUTO mode first, then back to SINGLE
            scope.send_command(":TRIGger:MODE AUTO")
            time.sleep(0.5)  # Brief delay
            scope.set_trigger_mode("SINGLE")
            print("Trigger reset and re-armed for single acquisition")
        
        future = executor.submit(reset_worker)
        future.result(timeout=10)
        
        return jsonify({"status": "success", "message": "Trigger reset and re-armed"})
        
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# File access API
@app.route('/api/download/<filename>')
def api_download(filename):
    """Download CSV file"""
    try:
        file_path = os.path.join(WAVEFORM_DIR, filename)
        if not os.path.exists(file_path):
            abort(404)
        return send_file(file_path, as_attachment=True)
    except Exception as e:
        abort(500)

@app.route('/api/plot/<filename>')
def api_plot(filename):
    """Serve plot image"""
    try:
        file_path = os.path.join(WAVEFORM_DIR, filename)
        if not os.path.exists(file_path):
            abort(404)
        return send_file(file_path, mimetype='image/png')
    except Exception as e:
        abort(500)

if __name__ == '__main__':
    print("Starting Flask oscilloscope control application...")
    print(f"Waveform data directory: {WAVEFORM_DIR}")
    app.run(host='0.0.0.0', port=5001, debug=True)
