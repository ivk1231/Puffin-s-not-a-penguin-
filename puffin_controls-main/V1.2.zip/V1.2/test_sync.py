#!/usr/bin/env python3
"""
Quick test script to verify oscilloscope connection
"""

import socket
import time

def test_connection():
    print("Testing oscilloscope connection...")
    print("Target: 192.168.1.10:5025")
    
    try:
        # Test basic TCP connection
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(5.0)
        
        result = sock.connect_ex(("192.168.1.10", 5025))
        if result == 0:
            print("✓ TCP connection successful")
            
            # Test SCPI command
            sock.sendall(b"*IDN?\n")
            sock.settimeout(2.0)
            response = sock.recv(1024)
            idn = response.decode('utf-8', errors='ignore').strip()
            print(f"✓ SCPI communication successful")
            print(f"  Device: {idn}")
            
            # Test another command
            sock.sendall(b"*OPC?\n")
            response = sock.recv(1024)
            opc = response.decode('utf-8', errors='ignore').strip()
            print(f"✓ Operation complete test: {opc}")
            
            sock.close()
            return True
        else:
            print(f"✗ TCP connection failed (error: {result})")
            return False
            
    except Exception as e:
        print(f"✗ Connection error: {e}")
        return False

if __name__ == "__main__":
    success = test_connection()
    print(f"\nConnection test: {'PASSED' if success else 'FAILED'}")
    
    if success:
        print("\n🎉 Your oscilloscope is ready!")
        print("Open http://127.0.0.1:5001 in your browser to use the web interface")
        print("Enable 'Real-time Synchronization' for automatic GUI ↔ scope sync")
    else:
        print("\n❌ Please check your oscilloscope network settings")
        print("Ensure it's connected to the same network and IP is 192.168.1.10")